plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
 namespace="com.tailormeasure.app"; compileSdk=35
 defaultConfig { applicationId="com.tailormeasure.app"; minSdk=23; targetSdk=35; versionCode=20; versionName="1.0.0-phone" }
}
dependencies {
 implementation("androidx.core:core-ktx:1.15.0")
 implementation("androidx.appcompat:appcompat:1.7.0")
 implementation("androidx.webkit:webkit:1.12.1")
}
