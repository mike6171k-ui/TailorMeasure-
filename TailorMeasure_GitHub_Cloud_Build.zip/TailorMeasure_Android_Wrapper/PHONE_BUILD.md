# TailorMeasure — Build APK using only your phone

This project includes a GitHub Actions workflow that builds the APK on GitHub's cloud servers.

## Phone-only steps

1. Open GitHub in your phone browser and create/sign in to an account.
2. Create a new repository named `TailorMeasure`.
3. Make the repository **Public** if you want to avoid private-repository limits on GitHub Actions.
4. Upload the contents of this project to the repository, preserving folders.
5. Open the repository's **Actions** tab.
6. Select **Build TailorMeasure APK**.
7. Tap **Run workflow**.
8. Wait for the workflow to finish successfully.
9. Open the completed workflow run.
10. Under **Artifacts**, download `TailorMeasure-debug-apk`.
11. Extract it and install `app-debug.apk` on your Tecno.

The workflow uses GitHub's Ubuntu runner with Java 17, Android SDK 35, Gradle 8.9 and Android Gradle Plugin 8.7.3.

## If GitHub asks about workflow permissions
Allow Actions to run for the repository.

## If Android blocks installation
Enable installation of apps from your browser/file manager when Android asks.

## Important
This creates a debug APK for testing. The measurement values in the current PWA are still prototype/demo values and must be validated against real tape measurements before production tailoring use.
