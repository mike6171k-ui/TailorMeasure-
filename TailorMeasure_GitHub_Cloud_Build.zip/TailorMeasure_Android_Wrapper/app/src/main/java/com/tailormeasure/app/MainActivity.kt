package com.tailormeasure.app
import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.*
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity: ComponentActivity() {
 private lateinit var web: WebView
 private val req=1001
 override fun onCreate(b:Bundle?) {
  super.onCreate(b); web=WebView(this)
  web.layoutParams=ViewGroup.LayoutParams(-1,-1)
  web.settings.javaScriptEnabled=true; web.settings.domStorageEnabled=true
  web.settings.allowFileAccess=true; web.settings.mediaPlaybackRequiresUserGesture=false
  web.webChromeClient=object: WebChromeClient(){
   override fun onPermissionRequest(r:PermissionRequest){
    runOnUiThread {
     if(ContextCompat.checkSelfPermission(this@MainActivity,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)
       ActivityCompat.requestPermissions(this@MainActivity,arrayOf(Manifest.permission.CAMERA),req)
     else r.grant(r.resources)
    }
   }
  }
  web.webViewClient=WebViewClient(); setContentView(web)
  if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)
    ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.CAMERA),req)
  web.loadUrl("file:///android_asset/index.html")
 }
 override fun onBackPressed(){if(web.canGoBack())web.goBack()else super.onBackPressed()}
}
