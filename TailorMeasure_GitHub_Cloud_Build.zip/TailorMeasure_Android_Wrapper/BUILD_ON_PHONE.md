# Build TailorMeasure on Android phone
Import this project into an Android IDE/build environment such as AndroidIDE.
Required: Android SDK 35, JDK 17+, Gradle/AGP 8.7.3.
Run the `app` debug build. APK: app/build/outputs/apk/debug/app-debug.apk.
The wrapper bundles the PWA locally and requests camera permission.
